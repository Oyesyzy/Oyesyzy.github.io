document.addEventListener("DOMContentLoaded", function() {
    console.log("Instagram-style website loaded!");
});
